from vinca._generators.two_lines import two_lines
from vinca._generators.verses import verses

generators_dict = {'2': two_lines,
		   'v': verses}
