from vinca.generators.two_lines import two_lines
from vinca.generators.verses import verses

generators_dict = {'2': two_lines,
		   'v': verses}
